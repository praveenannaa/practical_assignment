package phase1;

public class Try_CatchExample {
	   public static void main(String[] args) {  
	        try  
	        {  
	        }    
	        catch(ArithmeticException e)  
	        {  
	            System.out.println(e);  
	        }  
	        System.out.println("rest of the code");  
	    }  

}
